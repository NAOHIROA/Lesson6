# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '45e56312e142d65369d46a2174241df0b16a6b872f944204a09739aa3f13bb603677ce3fe9472363b27512d28c015c1053b68b32795ee5b34d47c1701574cd11'
